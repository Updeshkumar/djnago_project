from all_import.all_import import *


razorpay_client = razorpay.Client(auth=("rzp_test_ytKuITMg75DwVo", "kVHhmNwyqyTBwHEuSF170xHn"))


def driver_making_payment(request): 
    user = driver_profile.objects.get(user=request.user)
    get_amount = driver_payment_amount.objects.last().value
    
    currency = 'INR'
    amount = int(get_amount)*100   
    # Create a Razorpay Order
    razorpay_order = razorpay_client.order.create(dict(amount=amount,
                                                    currency=currency,
                                                    payment_capture='0'))
    razorpay_order_id = razorpay_order['id']
        # we need to pass these details to frontend.
    context = {}
    context['razorpay_order_id'] = razorpay_order_id
    context['razorpay_merchant_key'] = "rzp_test_ytKuITMg75DwVo"
    context['razorpay_amount'] = str(amount)
    context['currency'] = currency
    context['callback_url'] = "http://127.0.0.1:8000/driver-payhandler/"
    driver_payment.objects.create(
                    user = user ,
                    razorpay_order_id = razorpay_order_id ,
                    amount = int(get_amount) ,
                )
    print(context)
    return render(request , 'payment/payment.html' , context=context)



@csrf_exempt
def driver_payhandler(request):
    d_tody = date.today()
    if request.method == "POST":
        print("request is", request.POST)
        payment_id = request.POST.get('razorpay_payment_id', '')
        order_id = request.POST.get('razorpay_order_id', '')
        signature = request.POST.get('razorpay_signature', '')

        print(payment_id,order_id,signature)
        params_dict = {
                'razorpay_order_id': order_id,
                'razorpay_payment_id': payment_id,
                'razorpay_signature': signature
        }
        result = razorpay_client.utility.verify_payment_signature(
                params_dict)
       
        if result is not None:
            try:
                
                # capture the payemt
                # razorpay_client.payment.capture(payment_id, amount)
                # print("amount is " , amount)
                driver_payment.objects.filter(razorpay_order_id = order_id ).update(
                status = True,
                payment_id = payment_id
                )
                obj = driver_payment.objects.filter(razorpay_order_id = order_id , status=True ).first()
                driver_profile.objects.filter(id=obj.user.id).update(driver_paid=True ,
                                                    expired_at=d_tody.replace(d_tody.year + 1) )

                # render success page on successful caputre of payment
                messages.success(request, 'Your payment was successful')
                return redirect('account:home-dashboard')
            except Exception as e:
                print("exception",e)
                messages.error(request, 'Something went wrong!!')
                return redirect('')
        else:
            print(result)
            messages.error(request, 'Something went wrong!!')
            return redirect('/')


    